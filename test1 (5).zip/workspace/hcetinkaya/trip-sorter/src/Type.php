<?php
namespace TripSorter;

class Type {
    
    const PLANE = 'Plane';
    const TRAIN = 'Train';
    const BUS = 'Bus';
}